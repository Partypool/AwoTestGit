#ifndef ANSICHT_H
#define ANSICHT_H

#include <QObject>
#include <QWidget>
#include <QPolygonF>
#include <QPointer>

class Modell;

class Ansicht : public QWidget { Q_OBJECT
	Modell &modell;

public:
	explicit Ansicht(Modell &modell, QWidget *parent = nullptr);

protected:
	void paintEvent(QPaintEvent *event) override;
};

#endif // ANSICHT_H


