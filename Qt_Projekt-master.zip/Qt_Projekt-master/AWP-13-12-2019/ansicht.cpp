#include "ansicht.h"
#include <QMouseEvent>
#include <QPainter>
#include <QPaintEvent>
#include <modell.h>


Ansicht::Ansicht(Modell &modell, QWidget *parent)
: QWidget(parent)
, modell(modell)
{
	setFocusPolicy(Qt::StrongFocus);
	
	connect
	( &modell, &Modell::positionGeaendert
	, this, QOverload<>::of(&QWidget::update) );
}

void Ansicht::paintEvent(QPaintEvent *event) {
	QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);//"linie sieht glatter aus"
	
	double phi = 0;
	for(auto line : modell.getLineList()) {
        phi += 0.1;
		p.setPen(QPen(algo::color_wheel(phi), 3, Qt::SolidLine, Qt::RoundCap));
		p.drawLine(line);
	}
}
