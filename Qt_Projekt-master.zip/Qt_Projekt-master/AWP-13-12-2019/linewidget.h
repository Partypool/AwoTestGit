#ifndef LINEWIDGET_H
#define LINEWIDGET_H

#include <QWidget>
#include <QPolygonF>
#include <QPointer>


class Modell;

class LineWidget : public QWidget
{
    Q_OBJECT


    QPolygonF line;
    QPointer<Modell> modell;
public:
    explicit LineWidget(Modell* modell, QWidget *parent = nullptr);

signals:

public slots:

    // QWidget interface
protected:

    void paintEvent(QPaintEvent *event) override;
};

#endif // LINEWIDGET_H
