#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; } //fuer ui->setupUi(this);
QT_END_NAMESPACE

class Modell;
class Ansicht;
class LineController;

class MainWindow : public QMainWindow { Q_OBJECT
	Ui::MainWindow *ui;
	Modell *modell;
	Ansicht *lineAnsicht;
	LineController *steuerung;

public:
	MainWindow(QWidget *parent = nullptr);
	~MainWindow();

private slots:
	void on_actionCancel_triggered();
	void on_actionOpen_triggered();
	void on_actionSave_as_triggered();
	void on_actionNew_triggered();
};
#endif // MAINWINDOW_H
