#include "modell.h"

#include <QPolygonF>

Modell::Modell(QObject *parent) : QObject(parent) {}

void Modell::addpoint(const QPointF& point) {
	assert(!polygonlist.empty());
	polys_changed = true;
    polygonlist.back().append(point);
	positionGeaendert();
}

void Modell::addPolygon() {
	polys_changed = true;
	polygonlist.push_back(QPolygonF());
	positionGeaendert();
}

void Modell::polygonEntfernen(std::size_t index) {
	assert(index < polygonlist.size());
	polys_changed = true;
	polygonlist.erase(polygonlist.begin() + index);
	emit(positionGeaendert());
}
