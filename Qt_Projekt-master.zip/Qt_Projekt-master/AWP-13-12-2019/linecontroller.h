#ifndef LINECONTROLLER_H
#define LINECONTROLLER_H

#include <QObject>
#include <QPointer>
class QMouseEvent;
class QKeyEvent;

class Modell;
class Ansicht;



class LineController : public QObject { Q_OBJECT
	Modell &modell;
	Ansicht *ansicht;
	
	void mousePressEvent(QMouseEvent *event);
	void mouseMoveEvent(QMouseEvent *event);
	void mouseReleaseEvent(QMouseEvent *event);

public:
	explicit LineController
	( Modell &modell
	, Ansicht *ansicht
	, QObject *parent = nullptr );

	bool eventFilter(QObject *watched, QEvent *eevent) override;
};


#endif // LINECONTROLLER_H

