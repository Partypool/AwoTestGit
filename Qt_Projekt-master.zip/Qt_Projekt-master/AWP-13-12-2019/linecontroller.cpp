#include "linecontroller.h"

#include <QObject>
#include <QEvent>
#include <QMouseEvent>
#include <QKeyEvent>

#include "modell.h"
#include "ansicht.h"


LineController::LineController
( Modell &modell
, Ansicht *ansicht
, QObject *parent )
: QObject(parent), modell(modell), ansicht(ansicht)
{
	ansicht->installEventFilter(this);
}

bool LineController::eventFilter(QObject *watched, QEvent *event) {
	// Bestimmen des Ereignistyps (siehe auch Folien zur Ereignisbehandlung)
    switch(event->type()) {
        // relevante Ereignistypen behandeln:
        // cast auf speziellen Typ durchführen und die speziellen Event-Methoden aufrufen (der Übersichtlichkeitshalber)
        case QEvent::MouseButtonPress:
            mousePressEvent(dynamic_cast<QMouseEvent*>(event));
            break;
        case QEvent::MouseMove:
            mouseMoveEvent(dynamic_cast<QMouseEvent*>(event));
            break;
        default:
			return false;
	}
	return event->isAccepted();
}



void LineController::mouseReleaseEvent(QMouseEvent *event) {}

void LineController::mousePressEvent(QMouseEvent *event) {
	modell.addPolygon();
}

void LineController::mouseMoveEvent(QMouseEvent *event) {
	modell.addpoint(event->pos());
}














