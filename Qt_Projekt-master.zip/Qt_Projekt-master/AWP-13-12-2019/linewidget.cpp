#include "linewidget.h"

#include<QMouseEvent>
#include<QPainter>
#include <QPaintEvent>

#include<modell.h>

LineWidget::LineWidget(Modell* modell, QWidget *parent) : QWidget(parent)
  , modell(modell)
{
    setFocusPolicy(Qt::StrongFocus);

    connect(modell, &Modell::positionGeaendert, this, QOverload<>::of(&QWidget::update));

}

void LineWidget::paintEvent(QPaintEvent *event)
{
    if(!modell)
        return;

    auto& polygonliste = modell->getPolygonListe();

    QPainter painter(this);
    painter.setPen(Qt::cyan);
    for(const QPolygonF& poly : polygonliste)
        painter.drawPolyline(poly);

}
