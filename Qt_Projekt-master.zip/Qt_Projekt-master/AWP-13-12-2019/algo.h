
// zu jeder fkt eine mini notiz as es macht!!!!

#include <stdint.h>
#include <QtMath>
#include <QMainWindow>
#include <QPainter>
#include <QPaintEvent>



namespace algo {







static QColor color_wheel(double phi) {
	
	if(0)
	{
		static int64_t x = 0;
		x = x*2862933555777941757+3037000493;
		uint8_t r = x >> 32;
		uint8_t g = x >> 40;
		uint8_t b = x >> 48;
		return QColor(r, g, b);
	}
	
	double r = pow(cos(phi*1. + 1.)*.5+.5, .8);
	double g = pow(cos(phi*.5 + 2.)*.4+.4, .8);
	double b = pow(cos(phi*1. + 3.)*.5+.5, .8);
	return QColor(qFloor(r*255.), qFloor(g*255.), qFloor(b*255.));
}

struct Point {
	int64_t x, y;
	Point() : x(0), y(0) {}
	Point(int64_t x, int64_t y) : x(x), y(y) {}
	bool operator<(const Point &rhs) { return y == rhs.y ? x<rhs.x : y<rhs.y; }
	bool operator==(const Point &rhs) { return x == rhs.x && y == rhs.y; }
	bool operator!=(const Point &rhs) { return x != rhs.x || y != rhs.y; }
	QPoint to_qpoint() { return QPoint(x, y); }
};

struct Line {
	Point a, b;
	int64_t x, y, z;
	Line(Point _a, Point _b) : a(_a), b(_b) {
		if(b < a) std::swap(a, b);
		x = a.y - b.y;
		y = b.x - a.x;
		z = a.x*b.y - a.y*b.x;
	}
	
	bool operator<(Line &rhs) {
		return a==rhs.a ? b<rhs.b : a<rhs.a;
	}
	
	void draw(QPainter &p) {
		uint64_t r = reinterpret_cast<uint64_t>(this) % 1234567;
		double phi = r * .001;
		p.setPen(QPen(color_wheel(phi), 3, Qt::SolidLine, Qt::RoundCap));
		p.drawLine(a.to_qpoint(), b.to_qpoint());
	}
};

static Point point_from_lines(Line &lhs, Line &rhs) {
	int64_t x = lhs.y*rhs.z - lhs.z*rhs.y;
	int64_t y = lhs.z*rhs.x - lhs.x*rhs.z;
	int64_t z = lhs.x*rhs.y - lhs.y*rhs.x;
	return Point(x/z, y/z);
}

static int orientation(Line &lhs, Point &rhs) {
	int64_t val = lhs.x*rhs.x + lhs.y*rhs.y + lhs.z;
	if(val < 0) return -1;
	if(val > 0) return +1;
	return 0;
}

template<class T>
static void swapnpop(std::vector<T> &L, size_t i) {
	std::swap(L.back(), L[i]);
	L.pop_back();
}





static void emit_line(Line X
, std::vector<Line> &active
, std::vector<Line> &output
) {
	if(X.a == X.b) return;
	for(size_t i = 0; i < active.size(); i++) {
		Line Y = active[i];
		int y0 = orientation(X, Y.a);
		int y1 = orientation(X, Y.b);
		if(y0 == y1) continue;
		int x0 = orientation(Y, X.a);
		int x1 = orientation(Y, X.b);
		if(x0 == x1) continue;
		Point p = point_from_lines(X, Y);
		if(y0 && y1) {
			swapnpop(active, i--);
			emit_line(Line(Y.a, p), active, output);
			emit_line(Line(Y.b, p), active, output);
		}
		if(x0 && x1) {
			emit_line(Line(X.a, p), active, output);
			emit_line(Line(X.b, p), active, output);
			return;
		}
	}
	active.push_back(X);
}

static void split_crossing_lines(std::vector<Line> &lines) {
	std::sort(lines.begin(), lines.end());
	std::vector<Line> active;
	std::vector<Line> output;
	for(Line &X : lines) {
		for(size_t i = 0; i < active.size(); i++) {
			if(X.a < active[i].b) continue;
			output.push_back(active[i]);
			swapnpop(active, i--);
		}
		emit_line(X, active, output);
	}
	for(Line &X : active) output.push_back(X);
	std::swap(lines, output);
}


static void split_crossing_lines
( std::vector<QPolygonF> &input
, std::vector<QLineF> &output
) {
	std::vector<Line> lines;
	for(auto poly : input)
	for(int i = 1; i < poly.size(); i++) {
		auto a = poly[i-1];
		auto b = poly[i];
		lines.push_back(Line(Point(a.x(), a.y()), Point(b.x(), b.y())));
	}
	split_crossing_lines(lines);
	output.clear();
	for(auto line : lines) {
		output.push_back(QLineF(line.a.x, line.a.y, line.b.x, line.b.y));
	}
}









static void find_cycles(size_t node, size_t prev
, std::vector<std::vector<size_t>> &E
, std::vector<bool> &visited
, std::vector<size_t> &back
) {
	back[node] = prev;
	visited[node] = true;
	for(size_t next : E[node]) {
		if(next == prev) continue;
		if(visited[next]) {
		}
		else find_cycles(next, node, E, visited, back);
	}
}

static void find_polygons(std::vector<Line> &lines) {
	if(lines.empty()) return;
	
	std::vector<Line> edges;
	for(Line X : lines) {
		edges.push_back(X);
		std::swap(X.a, X.b);
		edges.push_back(X);
	}
	
	std::sort(edges.begin(), edges.end());
	std::vector<Point> V = {edges[0].a};
	
	for(Line &X : edges) {
		if(X.a == V.back()) continue;
		V.push_back(X.a);
	}
	
	std::vector<std::vector<size_t>> E(V.size());
	size_t i = 0;
	
	for(Line &X : edges) {
		if(X.a != V[i]) i++;
		size_t j = std::lower_bound(V.begin(), V.end(), X.b) - V.begin();
		E[i].push_back(j);
	}
	
	std::vector<size_t> back(V.size());
	std::vector<bool> visited(V.size());
	
	for(size_t i = 0; i < V.size(); i++)
		if(!visited[i]) find_cycles(i, i, E, visited, back);
}







}
