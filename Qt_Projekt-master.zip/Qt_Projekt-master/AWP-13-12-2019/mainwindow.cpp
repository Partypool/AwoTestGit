#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QFileDialog>
#include <QString>
#include <QDialog>
#include <QVBoxLayout>
#include <QWidget>

#include <modell.h>
#include <ansicht.h>
#include <linecontroller.h>

MainWindow::MainWindow(QWidget *parent)
: QMainWindow(parent)
, ui(new Ui::MainWindow)
{
	ui->setupUi(this);
	setStyleSheet("background-color: #667;");
	
	modell = new Modell(this);
	lineAnsicht = new Ansicht(*modell, parent);
	steuerung = new LineController(*modell, lineAnsicht, this);
	
    setCentralWidget(lineAnsicht);
}

MainWindow::~MainWindow() {}

void MainWindow::on_actionCancel_triggered() {
	this->close();
}

void MainWindow::on_actionOpen_triggered() {
	QStringList dateiename = QFileDialog::getOpenFileNames(this
	, tr("Select one or more files to open"), ""
	, tr("Images (*.png *.xpm *.jpg)"));
}

void MainWindow::on_actionSave_as_triggered() {
	QString fileName = QFileDialog::getSaveFileName(this
	, tr("Save File"), ""
	, tr("Images (*.png *.xpm *.jpg)"));
}

//müssten wir hier nicht ein neues Wainwindow erzeugen? i vote: new = delete all und vorher speicherabfrage
void MainWindow::on_actionNew_triggered() {
	MainWindow* neu = new MainWindow;
	this->pos();
    neu->move(this->pos().x()+30, this->pos().y()+30);
	neu->show();
}












