#ifndef MODELL_H
#define MODELL_H

#include <QObject>
#include <QPointF>
#include "algo.h"

class Modell : public QObject { Q_OBJECT
	
	QPointF pos;
	std::vector<QPolygonF> polygonlist;
	std::vector<QLineF> linelist;
	bool polys_changed;

public:
	explicit Modell(QObject *parent = nullptr);
	QPointF gibposition() const { return pos; }
	
	void addpoint(const QPointF &point);
	void addPolygon();
	void polygonEntfernen(std::size_t index);
	
	const std::vector<QPolygonF> &getPolygonList() const {
		return polygonlist;
	}
	
	const std::vector<QLineF> &getLineList() {
		if(polys_changed) algo::split_crossing_lines(polygonlist, linelist);
		return linelist;
	}
	
signals:
	void positionGeaendert();
};

#endif // MODELL_H
